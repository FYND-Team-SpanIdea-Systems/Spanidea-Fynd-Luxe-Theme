export default {
    testpage: {
        component: () => import("./example.vue"),
        header: false,
        footer: false
    }
};